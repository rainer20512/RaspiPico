#pragma once

// #include <unistd.h>
#include <stdint.h>
extern int ExitOnFail;

int 			I2C_IO_Open(int BUS, int SlaveAddress);
int       TxtFileOpen(const char *filename);
int 			I2C_IO_SlaveAddress(int handle, int SlaveAddress);
void 			I2C_IO_SetTimeout( int file, int timeoutms);
void      I2C_IO_WriteRaw(int file, int address, uint8_t *data, const int size );
int 			I2C_IO_ReadRaw (int file, int address, uint8_t *retbuf, const int readsize);
#define 	I2C_IO_Close(HDL) 	close(HDL)
#define 	TxtFileClose(HDL) 		close(HDL)
