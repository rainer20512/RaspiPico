/******************************************************************************
 * Utility funcions
 *****************************************************************************/

#include <sys/time.h>
#include <stddef.h>
#include <stdint.h>

long long timestamp_ll() {
    struct timeval te; 
    gettimeofday(&te, NULL); // get current time
    long long milliseconds = te.tv_sec*1000LL + te.tv_usec/1000; // calculate milliseconds
    // printf("milliseconds: %lld\n", milliseconds);
    return milliseconds;
}

uint32_t timestamp_u32() {
    struct timeval te; 
    gettimeofday(&te, NULL); // get current time
    long long milliseconds = te.tv_sec*1000LL + te.tv_usec/1000; // calculate milliseconds
    // printf("milliseconds: %lld\n", milliseconds);
    return milliseconds & 0x7FFFFFFFUL;
}