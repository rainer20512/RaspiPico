#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <linux/input.h>
#include <fcntl.h>
#include <linux/i2c-dev.h>
#include <linux/i2c.h>
#include <string.h>

#include "i2c_io.h"
////////////////////////////////////   I2C_IO_Open
//
//    Open I2C I/O
//
//    Inputs,
//
//    BUS :  select  bus  (Rpi is 0 or 1)
//    SlaveAddress:  between 0x3 .. 0x77
//
//    Return,
//
//    IO handle for  open()
//

int ExitOnFail=1;
int DisplayFailMessage=1;

void FailMessage(char *msg)
{
  if(DisplayFailMessage)
     {
       fprintf(stderr,msg);
       fflush(stderr);
     }

   if(ExitOnFail)
      exit(0);
}


int TxtFileOpen(const char *filename) 
{
	  int handle = open(filename, O_RDONLY);
	  if(handle < 0) {
	     fprintf(stderr,"Failed to open the file %s bus \n", filename);
	     fflush(stderr);
	   }
	   return handle;
}

int I2C_IO_Open(int BUS, int SlaveAddress)
    {
	  int handle;
	  char I2C_dev[256];

	  if(BUS < 0) return -1;
	  if(BUS > 1) return -1;

	  sprintf(I2C_dev,"/dev/i2c-%d", BUS);

	  handle = open(I2C_dev, O_RDWR);
	  if(handle < 0)
	   {
	     FailMessage("Failed to open the i2c bus \n");
	    return -1;
	   }
	   
	  // ioctl(handle, I2C_SET_SPEED, 100000);
	  if(I2C_IO_SlaveAddress(handle,SlaveAddress) < 0)
	   {
	      close(handle);
		    return -2;
	   }
	   return handle;
	}



////////////////////////////////////   I2C_IO_SlaveAddress
//
//    Specify which Slave device you want to talk to
//
//     inputs,
//
//     handle:   IO handle
//     SlaveAddress:
//
//    Return integer
//
//    0  ok
//    < 0 error
//

int I2C_IO_SlaveAddress(int handle, int SlaveAddress)
    {
       if(SlaveAddress < 3) return -1;
       if(SlaveAddress > 0x77)return -1;

	   if (ioctl(handle, I2C_SLAVE, SlaveAddress) < 0)
	    {
               FailMessage("Failed to acquire bus access and/or talk to slave.\n");
		return -1;
		}
        return 0; // ok
    }


void I2C_IO_SetTimeout( int file, int timeoutms)
{
		if (ioctl(file, I2C_TIMEOUT, timeoutms/10) < 0) {
        perror("Failed to set I2C_TIMEOUT");
    }
}


void I2C_IO_WriteRaw(int file, int address, uint8_t *data, const int size)
{
    ioctl(file, I2C_SLAVE, address);  // real code would need to check for an error
    int numwritten = write(file, data, size ); 
    #if DEBUG_I2C > 0
		    for (int i=0; i< size; i++ ) putchar(*(data+i));
   	 		printf("Sent %d bytes to address 0x%02x\n", numwritten, address );
   	#endif
    if ( numwritten >= 0 && numwritten != size ) {
    		if ( numwritten > size ) printf("Err: Wrote %d excess bytes\n", numwritten-size );
    		if ( numwritten < size ) printf("Err: %d bytes not sent\n", size-numwritten );
    } else if ( numwritten < 0 ) printf("Err: write err %d\n", numwritten );			
}

int I2C_IO_ReadRaw(int file, int address, uint8_t *retbuf, const int readsize) 
{
		int numread;

    ioctl(file, I2C_SLAVE, address);  // real code would need to check for an error
    numread = read(file, retbuf, readsize);
		if ( numread < 0 ) {
    		printf("Err: Read err %d, timeout?\n", numread );
		} else {
    #if DEBUG_I2C > 0
		    printf("Read %d bytes from address %d\n", numread, address);
		    for ( int i=0; i< numread; i++ ) printf("R%02x",*(retbuf+i));
		    printf("\n");
		#endif
		}
		
		return numread;
}
