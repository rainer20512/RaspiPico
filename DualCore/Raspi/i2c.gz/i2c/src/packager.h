/******************************************************************************
 * Pack the outgoing i2c data in a wrapper datastructure
 * unpack the incoming i2c data from the wrapper data structure
 *****************************************************************************/

#pragma once

#include <stdbool.h>
#include <stdint.h>

void    SendParserReset     (void);
void 		SendRawData					(uint8_t *rawdata, uint8_t datalen);
int 		ReadFlexSizePacket 	(uint8_t expectedsize); 
uint8_t *GetReadBuffer 			(void); 
bool 		WaitForSlaveIdle		(void );
bool 		SlaveHasData 				(uint8_t *datalen);