#include <stdint.h>

#define SENDBUFSIZE						32			/* Buffersize for i2c write transfers */
#define RECVBUFSIZE						128			/* Buffersize for i2c read  transfers */
extern int i2c_handle;								/* filehandle for i2c device file     */	
extern int txtfile;										/* filehandle for txt file to be send */
extern uint8_t i2c_addr;              /* i2c address (7 bit ) to use        */
extern unsigned 
      char sendbuf[SENDBUFSIZE];			/* i2c send buffer                    */
extern unsigned
      char recvbuf[SENDBUFSIZE];			/* i2c recv buffer                    */
#define TERMINATION_CHAR 			0x04		/* a char that defines end of input   */		
#define IDLESCANWAITMS				50      /* waittime between two wait for idle checks */
#define I2C_TIMEOUTMS					500	  	/* timeout in i2c Operations          */			
#define I2C_WAITIDLETIMEOUTMS 2000    /* Timeout when waiting for idle      */
#define TXFLAG_PARSER_RESET		0x10  	/* Tell I2C slave to reset its parser */
#define TXFLAG_QRY_STATUS    	0x11  	/* Tell i2C slave to send its status in next i2c slave read */
#define TXFLAG_RAW_DATA      	0x55  	/* Tell i2c slave, that package contains raw data */

/* Answer flag bits for "query status"  */
#define I2C_SLAVEFLAG_BUSY    (1<<0)	/* i2c slave is busy                  */
#define I2C_SLAVEFLAG_HASDATA (1<<1)	/* i2c slave has additional raw data  */	