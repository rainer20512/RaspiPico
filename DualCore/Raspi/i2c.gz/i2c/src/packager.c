/******************************************************************************
 * Pack the outgoing i2c data in a wrapper datastructure
 * unpack the incoming i2c data from the wrapper data structure
 *****************************************************************************/

 #include <string.h>
 #include <stdbool.h>
 #include <stdio.h>
 #include <unistd.h>
 
 #include "global.h"
 #include "i2c_io.h"
 #include "util.h"
  
 /* Define two I2C Buffers for transfers to and receives from clients */
 #if SENDBUFSIZE > RECVBUFSIZE	
 		#define I2CBUFSIZE SENDBUFSIZE
 #else
 		#define I2CBUFSIZE RECVBUFSIZE
 #endif
 
typedef struct{
 	 uint8_t wrlen;									/* total size of packet, length and flags byte excluded! */
 	 uint8_t wrflags;         			/* flag bytes */
 	 uint8_t wrbytes[SENDBUFSIZE];	/* raw transfer data */
} I2C_Write_WrapperT;
 
typedef struct{
 	 uint8_t rdlen;									/* total size of packet, length and flags byte excluded! */
 	 uint8_t rdflags;								/* flag bytes */
 	 uint8_t rdbytes[RECVBUFSIZE];	/* raw transfer data */
} I2C_Read_WrapperT;
 
#define WRAPPER_EXCESS_BYTES		2 /* number of bytes added by length and flag Bytes */

static I2C_Write_WrapperT i2c_wr;
static I2C_Read_WrapperT  i2c_rd;
 
/******************************************************************************
 * Read a packet of fixed size into i2c_rd
 * use std timeout as read timeout
 * fixedsize is without length and flag bytes
 * true is returned on success, false on timeout or size diffs
 *****************************************************************************/
static bool ReadFixedSizePacket ( uint8_t fixedsize ) 
{
		uint8_t expectedsize = fixedsize+WRAPPER_EXCESS_BYTES;
		int ret = I2C_IO_ReadRaw(i2c_handle, i2c_addr, (uint8_t *)&i2c_rd, expectedsize);

    if ( ret  != expectedsize ) {
    		printf("Err: Read size diff, got %d, expected %d\n", ret, expectedsize);
    }
		
		/* flag read errors */
	  return ( ret == expectedsize );
}

/******************************************************************************
 * Read a packet of flexible size into i2c_rd.rdbytes
 * Number of read bytes may be lower than expected
 *
 * number of read data bytes is returned in case of success,
 * negative value in case of errors
 *****************************************************************************/
int ReadFlexSizePacket ( uint8_t expectedsize ) 
{
		int 		ret;
		
		if ( expectedsize > 0 ) {
				ret = I2C_IO_ReadRaw(i2c_handle, i2c_addr, i2c_rd.rdbytes, expectedsize);
				if ( ret < 0 ) {
						/* flag read errors */
						fprintf(stderr,"FlexSizeRead: Data Read Error\n");
			  		return ret;
				}
				if ( ret != expectedsize ) {
						fprintf(stderr,"FlexSizeRead: Real (%d) and expected (%d) sizes differ\n",
										ret, expectedsize);
			  }
			  return ret;
		} else {
				return 0;
		}
}

/******************************************************************************
 * Retrun a pointer to the begin of the read buffer 
 * negative value in case of errors
 *****************************************************************************/
uint8_t *GetReadBuffer ( void ) 
{
		return i2c_rd.rdbytes;
}

/******************************************************************************
 * Send the TX-Packet in "i2c_wr" 
 * Use "PackWriteWrapper" to prepare
 *****************************************************************************/
static void WritePacket ( void ) 
{
		I2C_IO_WriteRaw(i2c_handle, i2c_addr, (uint8_t *)&i2c_wr, i2c_wr.wrlen+WRAPPER_EXCESS_BYTES);
		#if DEBUG_PKG	
			printf("Master wrote %d bytes, type 0x%02x\n", i2c_wr.wrlen+WRAPPER_EXCESS_BYTES, i2c_wr.wrflags);
		#endif
}


/******************************************************************************
 * Prepare a TX-Packet
 * will return false, if datalen exceedes maximum sendbuffer size
 *****************************************************************************/
static bool PackWriteWrapper ( uint8_t flags, uint8_t *rawdata, uint8_t datalen )
{
		i2c_wr.wrlen 	 = datalen;
		i2c_wr.wrflags = flags;
		if ( datalen ) {
			if ( datalen > SENDBUFSIZE ) {
				fprintf(stderr,"Write data too long! (+%d Bytes),not sent!\n", datalen - SENDBUFSIZE);
				return false;
			}
			memmove(i2c_wr.wrbytes, rawdata, datalen);
		}
		return true;
}
 
/******************************************************************************
 * Send raw data to slave,
 * be sure, slave is in idle before send, by using "WaitForSlaveIdle" eg
 *****************************************************************************/
void SendRawData(uint8_t *rawdata, uint8_t datalen)
{
		if ( PackWriteWrapper( TXFLAG_RAW_DATA, rawdata, datalen) )
		{
				WritePacket();
		}
}

/******************************************************************************
 * get the flag bytes from i2c slave and check the "busy" flags
 * all other flags may be queried later by "I2C_GetSlaveFlags"
 * Will do an active wait, as long as slave is busy
 * false is returned, whenever slave does not answer withing timeout period
 * or when total wait time execeedes wait timeout
 *****************************************************************************/
bool WaitForSlaveIdle(void )
{
		bool ret;
		uint32_t stop_time;
		#if DEBUG_PKG	
				uint32_t start_time = timestamp_u32();
		#endif
		
		stop_time = timestamp_u32() + I2C_WAITIDLETIMEOUTMS;
		PackWriteWrapper(TXFLAG_QRY_STATUS, NULL, 0 );
		/* Query Status repeatedly as long as busy flag is set */
		/* and status wait timeour not reached */
		do {
				WritePacket();
				ret = ReadFixedSizePacket(0);
				if ( (i2c_rd.rdflags & I2C_SLAVEFLAG_BUSY) == 0 ) break;
				usleep(IDLESCANWAITMS*1000);
		} while ( ret && timestamp_u32() <= stop_time );

		#if DEBUG_PKG	
	    	printf("%dms waiting for slave idle, got %d\n",timestamp_u32() - start_time, i2c_rd.rdflags); 
		#endif
		return (i2c_rd.rdflags & I2C_SLAVEFLAG_BUSY) == 0;		
}	 

/******************************************************************************
 * Send xml parser reset command to slave
 *****************************************************************************/
void SendParserReset(void)
{
		PackWriteWrapper(TXFLAG_PARSER_RESET, NULL, 0 );
		WritePacket();
		/* give some time to execute cmd */
		usleep(IDLESCANWAITMS);
}
/******************************************************************************
 * returns true, if slave has data to be queried by master
 * length of data will be returned in "datalen"
 * call of this routine is vaild only, if "WaitForSlaveIdle" has
 * returned true
 *****************************************************************************/
bool SlaveHasData ( uint8_t *datalen )
{
		bool ret = (i2c_rd.rdflags & I2C_SLAVEFLAG_HASDATA) != 0;
		if ( ret ) {	
				/* length of raw data is stored in length byte */
				*datalen = i2c_rd.rdlen;
				#if DEBUG_PKG	
						printf("Slave has data, len%d\n", *datalen);
				#endif
		} else {
				#if DEBUG_PKG	
						printf("Slave has no data\n");
				#endif
		}
		return ret;		
}