#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "global.h"
#include "i2c_io.h"
#include "packager.h"
#include "util.h"

#define SENDBUFSIZE			32		/* Buffersize for i2c write transfers       */
#define RECVBUFSIZE			128		/* Buffersize for i2c read  transfers       */
int i2c_handle;								/* filehandle for i2c device file     */	
int txtfile;									/* filehandle for txt file to be send */
uint8_t i2c_addr;             /* i2c address (7 bit ) to use        */
unsigned 
char sendbuf[SENDBUFSIZE];		/* i2c send buffer                    */
unsigned
char recvbuf[SENDBUFSIZE];		/* i2c recv buffer                    */
int  sendbufidx = 0;          /* actual send buffer write offset    */
int  recvbufidx = 0;          /* actual recv buffer write offset    */
int ws_counter  = 0;					/* counter for whitespace characters  */
int send_count  = 0;          /* counter for sent buffers           */
int char_count  = 0;      		/* counter for sent characters        */	
int qm_counter  = 0;          /* quotation mark counter: don't chng text within quotes */

#define SENDBUF_INIT()			   sendbufidx = 0
#define SENDBUF_EMPTY()				(sendbufidx == 0) 
#define SENDBUF_FULL()				(sendbufidx >= SENDBUFSIZE) 
#define DO_STRIPPING		1			/* remove all white space before send */

#define IS_WHITESPACE(c)      ( c== 0x04 || c==0x09 || c==0x0a || c==0x0b || c==0x0c || c==0x0d || c==' ' )
#define OUTSIDE_QUOTES()				( (ws_counter & 1 ) == 0 )

void msgbuf_get (uint8_t datalen)
{
		int size = ReadFlexSizePacket(datalen);
	  if ( size ) {
	  	  uint8_t *buf = GetReadBuffer();
				write(STDERR_FILENO, buf, size );
		}
}			

void sendbuf_flush(int i2c_addr)
{
		uint8_t datalen;

		/* Wait for pending read operations from preceeding calls to finish */
		usleep(100000);
		/* First Wait for Slave Idle */
		if ( !WaitForSlaveIdle() ) {
				fprintf(stderr, "Cannot determine slave status, not send\n");
				return;
		}

		/* Then read slave data, if available */
		if ( SlaveHasData(&datalen) ) {
				msgbuf_get(datalen);
				// usleep(100000);
		}
		
		/* any data to send at all? */
		if ( SENDBUF_EMPTY() ) return;	 
 
 		SendRawData(sendbuf, sendbufidx);
 		char_count += sendbufidx;
 		send_count += 1;
 		SENDBUF_INIT();

    /*
		msgbuf_get(i2c_addr);
		usleep(250000);
		*/
}

void sendbuf_put(char c)
{
		/* caller must ensure, there is space left in sendbuf */
		sendbuf[sendbufidx++] = c;
}

void sendtxtfile(int i2c_addr)
{
		char ch;
	
		SENDBUF_INIT();
		ws_counter = qm_counter = 0;
		while (read(txtfile, &ch, 1) > 0) {
				if ( ch == '"' ) qm_counter++;
			  /* don't alter text within quotes */
				if ( OUTSIDE_QUOTES() ) {
					if ( DO_STRIPPING ) {
							/* only keep one whitespace character in a sequence */ 	
							if ( IS_WHITESPACE(ch) ) {
									if ( ws_counter++ > 0 ) continue; 
							} else {
									ws_counter = 0;
							}
					}
				}
				sendbuf_put(ch);
				if ( SENDBUF_FULL() ) {
						sendbuf_flush(i2c_addr);
				}
		}
			
	/* send termination char and flush rest of buffer */
	sendbuf_put(TERMINATION_CHAR);
	sendbuf_flush(i2c_addr);
	/* maybe the last flush generated output data,get it */
	sendbuf_flush(i2c_addr);
}

int main ( int argc, char *argv[] )
{
	
/*
		printf("Start=%d\n", timestamp_u32() );
		uint32_t stop_time = timestamp_u32()+1000;
		while ( timestamp_u32() < stop_time );
		printf("Stop=%d\n", timestamp_u32() );
*/
		
		void usage(void) {
			printf("%s <i2c addr> <file>\n", argv[0] );
		}

		if ( argc < 2 ) { usage(); exit(1); }

		i2c_addr = atoi(argv[1]);
		
    /* open ic2 device file */
    i2c_handle = I2C_IO_Open(1, i2c_addr);
    if ( i2c_handle < 0 ) exit(1);
		 
		I2C_IO_SetTimeout( i2c_handle, I2C_TIMEOUTMS );


// 		msgbuf_get(i2c_addr);

		txtfile = TxtFileOpen(argv[2]);
		if ( txtfile >= 0 ) {
			SendParserReset();
			sendtxtfile(i2c_addr);

			TxtFileClose(txtfile);
	  }
  	
		I2C_IO_Close(i2c_handle);
		
		printf("Send %d chars in %d I2C-Transfers\n", char_count, send_count);
}

